import { useState, useEffect } from 'react';
import { Menu, X, Mail, Phone, Github, Linkedin, ExternalLink, Code, BookOpen, Award, Briefcase, GraduationCap, FileText, ChevronDown } from 'lucide-react';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);

      const sections = ['home', 'about', 'skills', 'experience', 'education', 'projects', 'publications', 'certifications', 'contact'];
      const current = sections.find(section => {
        const element = document.getElementById(section);
        if (element) {
          const rect = element.getBoundingClientRect();
          return rect.top <= 100 && rect.bottom >= 100;
        }
        return false;
      });
      if (current) setActiveSection(current);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100">
      {/* Navigation */}
      <nav className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-gray-900/95 backdrop-blur-sm shadow-lg' : 'bg-transparent'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex-shrink-0">
              <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
                CS Tatolu
              </h1>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex space-x-8">
              {['Home', 'About', 'Skills', 'Experience', 'Projects', 'Contact'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item.toLowerCase())}
                  className={`transition-colors duration-300 hover:text-blue-400 ${
                    activeSection === item.toLowerCase() ? 'text-blue-400' : 'text-gray-300'
                  }`}
                >
                  {item}
                </button>
              ))}
            </div>

            {/* Mobile menu button */}
            <button
              className="md:hidden text-gray-300 hover:text-white"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden bg-gray-800/95 backdrop-blur-sm">
            <div className="px-2 pt-2 pb-3 space-y-1">
              {['Home', 'About', 'Skills', 'Experience', 'Projects', 'Contact'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item.toLowerCase())}
                  className="block w-full text-left px-3 py-2 text-gray-300 hover:text-blue-400 hover:bg-gray-700 rounded-md transition-colors duration-300"
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 via-gray-900 to-cyan-900/20"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32 relative z-10">
          <div className="text-center space-y-6 animate-fade-in">
            <h2 className="text-5xl sm:text-6xl md:text-7xl font-bold">
              Hi, I'm{' '}
              <span className="bg-gradient-to-r from-blue-400 via-cyan-400 to-teal-400 bg-clip-text text-transparent">
                Chandana Sai Tatolu
              </span>
            </h2>
            <p className="text-xl sm:text-2xl md:text-3xl text-gray-300">
              AI & Machine Learning Specialist
            </p>
            <p className="text-lg text-gray-400 max-w-2xl mx-auto">
              CSE graduate specialized in building and deploying data-driven solutions with a passion for innovation
            </p>
            <div className="flex flex-wrap justify-center gap-4 pt-8">
              <a
                href="#contact"
                className="px-8 py-3 bg-blue-500 hover:bg-blue-600 rounded-full font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-blue-500/50"
              >
                Get In Touch
              </a>
              <a
                href="#projects"
                className="px-8 py-3 border-2 border-blue-400 hover:bg-blue-400/10 rounded-full font-semibold transition-all duration-300 transform hover:scale-105"
              >
                View My Work
              </a>
            </div>
            <div className="flex justify-center gap-6 pt-8">
              <a href="https://github.com/chandanasai1672004" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-blue-400 transition-colors duration-300">
                <Github size={28} />
              </a>
              <a href="https://www.linkedin.com/in/chandana-sai-tatolu" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-blue-400 transition-colors duration-300">
                <Linkedin size={28} />
              </a>
              <a href="mailto:chandanasai1672004@gmail.com" className="text-gray-400 hover:text-blue-400 transition-colors duration-300">
                <Mail size={28} />
              </a>
            </div>
          </div>
          <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce">
            <ChevronDown size={32} className="text-gray-400" />
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-gray-800/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-center mb-12">
            About <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">Me</span>
          </h2>
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <p className="text-lg text-gray-300 leading-relaxed">
                Highly analytical CSE graduate specialized in AI and Machine Learning with a proven ability to build and deploy data-driven solutions.
              </p>
              <p className="text-lg text-gray-300 leading-relaxed">
                Eager to contribute technical versatility and an innovative approach to a challenging, growth-focused team. My expertise spans across machine learning algorithms, web development, and cloud computing.
              </p>
              <div className="flex flex-wrap gap-4 pt-4">
                <div className="flex items-center gap-2 text-gray-300">
                  <Phone size={20} className="text-blue-400" />
                  <span>+91-8919026938</span>
                </div>
                <div className="flex items-center gap-2 text-gray-300">
                  <Mail size={20} className="text-blue-400" />
                  <span>chandanasai1672004@gmail.com</span>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-6">
              <div className="bg-gray-900/50 p-6 rounded-lg border border-gray-700 hover:border-blue-400 transition-all duration-300">
                <GraduationCap size={32} className="text-blue-400 mb-4" />
                <h3 className="text-2xl font-bold mb-2">8.39</h3>
                <p className="text-gray-400">CGPA</p>
              </div>
              <div className="bg-gray-900/50 p-6 rounded-lg border border-gray-700 hover:border-blue-400 transition-all duration-300">
                <Code size={32} className="text-cyan-400 mb-4" />
                <h3 className="text-2xl font-bold mb-2">10+</h3>
                <p className="text-gray-400">Projects</p>
              </div>
              <div className="bg-gray-900/50 p-6 rounded-lg border border-gray-700 hover:border-blue-400 transition-all duration-300">
                <Award size={32} className="text-teal-400 mb-4" />
                <h3 className="text-2xl font-bold mb-2">5+</h3>
                <p className="text-gray-400">Certifications</p>
              </div>
              <div className="bg-gray-900/50 p-6 rounded-lg border border-gray-700 hover:border-blue-400 transition-all duration-300">
                <FileText size={32} className="text-green-400 mb-4" />
                <h3 className="text-2xl font-bold mb-2">1</h3>
                <p className="text-gray-400">Publication</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-center mb-12">
            Technical <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">Skills</span>
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <SkillCard
              title="Programming Languages"
              skills={['C', 'Java', 'Python']}
              icon={<Code className="text-blue-400" />}
            />
            <SkillCard
              title="Web Development"
              skills={['HTML', 'CSS', 'JavaScript', 'PHP']}
              icon={<Code className="text-cyan-400" />}
            />
            <SkillCard
              title="Cloud & Database"
              skills={['Salesforce Platform', 'MySQL']}
              icon={<Code className="text-teal-400" />}
            />
            <SkillCard
              title="Developer Tools"
              skills={['Git', 'GitHub', 'VS Code', 'Jupyter Notebook']}
              icon={<Code className="text-green-400" />}
            />
            <SkillCard
              title="ML/Data Science"
              skills={['Pandas', 'NumPy', 'Scikit-learn', 'XGBoost']}
              icon={<Code className="text-purple-400" />}
            />
            <SkillCard
              title="Domains"
              skills={['Artificial Intelligence', 'Machine Learning', 'Operating Systems']}
              icon={<Code className="text-pink-400" />}
            />
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section id="experience" className="py-20 bg-gray-800/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-center mb-12">
            <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">Experience</span>
          </h2>
          <div className="max-w-3xl mx-auto">
            <div className="bg-gray-900/50 p-8 rounded-lg border border-gray-700 hover:border-blue-400 transition-all duration-300">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-blue-500/10 rounded-lg">
                  <Briefcase size={24} className="text-blue-400" />
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold mb-2">Machine Learning Intern</h3>
                  <p className="text-blue-400 mb-2">CAMPALIN</p>
                  <p className="text-gray-400 mb-4">Sep 2022 – Oct 2022</p>
                  <ul className="list-disc list-inside space-y-2 text-gray-300">
                    <li>Completed a course in Machine Learning and enhanced skills in data processing and model evaluation</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Education Section */}
      <section id="education" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-center mb-12">
            <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">Education</span>
          </h2>
          <div className="space-y-8 max-w-4xl mx-auto">
            <EducationCard
              degree="Bachelor of Technology"
              major="Computer Science (Artificial Intelligence and Machine Learning)"
              institution="Vignan Institute of Technology and Science"
              location="Hyderabad, Telangana"
              period="2021-2025"
              grade="CGPA: 8.39/10.0"
            />
            <EducationCard
              degree="Senior Secondary"
              major=""
              institution="Narayana Junior College"
              location="Hyderabad, Telangana"
              period="2019–2021"
              grade="Percentage: 97.20%"
            />
            <EducationCard
              degree="Secondary School Certificate"
              major=""
              institution="Dilsukhnagar Public School"
              location="Hyderabad, Telangana"
              period="2018-2019"
              grade="GPA: 9.8/10.0"
            />
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 bg-gray-800/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-center mb-12">
            Featured <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">Projects</span>
          </h2>
          <div className="grid md:grid-cols-2 gap-8">
            <ProjectCard
              title="BloodBank Management System"
              description="Developed a web-based Blood Bank Management System using PHP for the backend, enabling users to check the real-time availability of specific blood types and securely store and manage donor and inventory data."
              tech={['PHP', 'MySQL', 'HTML', 'CSS', 'JavaScript']}
              githubLink="https://github.com/chandanasai1672004"
            />
            <ProjectCard
              title="Safe Mother: Intelligent Risk Prediction"
              description="Deployed the XGBoost Algorithm after performance comparison with three other supervised ML models, achieving 84% classification accuracy in predicting Low, Medium, or High pregnancy risk. Utilized Pandas and NumPy for robust data preprocessing and statistical analysis."
              tech={['Python', 'XGBoost', 'Pandas', 'NumPy', 'Scikit-learn']}
              githubLink="https://github.com/chandanasai1672004"
            />
          </div>
        </div>
      </section>

      {/* Publications Section */}
      <section id="publications" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-center mb-12">
            <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">Publications</span>
          </h2>
          <div className="max-w-3xl mx-auto">
            <div className="bg-gray-900/50 p-8 rounded-lg border border-gray-700 hover:border-blue-400 transition-all duration-300">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-blue-500/10 rounded-lg">
                  <BookOpen size={24} className="text-blue-400" />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold mb-2">Car Parking System Using IOT</h3>
                  <p className="text-gray-400 mb-2">May 2024</p>
                  <a
                    href="https://doi.org/10.58532/V3BBIO1P1CH8"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-blue-400 hover:text-blue-300 transition-colors duration-300"
                  >
                    <span>DOI: 10.58532/V3BBIO1P1CH8</span>
                    <ExternalLink size={16} />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Certifications Section */}
      <section id="certifications" className="py-20 bg-gray-800/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-center mb-12">
            Certifications & <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">Achievements</span>
          </h2>
          <div className="grid md:grid-cols-2 gap-6 max-w-5xl mx-auto">
            <CertificationCard
              title="Communication Skills & Personal Development"
              issuer="Centre for English Language Training (Osmania University)"
            />
            <CertificationCard
              title="Programming in JAVA and Cloud Computing"
              issuer="National Programme on Technology Enhanced Learning (NPTEL)"
            />
            <CertificationCard
              title="Programming Essentials in Python"
              issuer="Cisco Networking Academy"
            />
            <div className="bg-gradient-to-br from-blue-500/10 to-cyan-500/10 p-6 rounded-lg border border-blue-400">
              <Award size={32} className="text-blue-400 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Elite Silver Certification</h3>
              <p className="text-gray-300">Cloud Computing by NPTEL</p>
            </div>
            <div className="bg-gradient-to-br from-blue-500/10 to-cyan-500/10 p-6 rounded-lg border border-blue-400">
              <Award size={32} className="text-cyan-400 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Academic Scholarship</h3>
              <p className="text-gray-300">High GPA in B.Tech 1st year</p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-center mb-12">
            Get In <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">Touch</span>
          </h2>
          <div className="max-w-2xl mx-auto text-center space-y-8">
            <p className="text-lg text-gray-300">
              I'm always open to discussing new projects, creative ideas, or opportunities to be part of your vision.
            </p>
            <div className="grid md:grid-cols-3 gap-6">
              <a href="mailto:chandanasai1672004@gmail.com" className="bg-gray-900/50 p-6 rounded-lg border border-gray-700 hover:border-blue-400 transition-all duration-300 group">
                <Mail size={32} className="text-blue-400 mx-auto mb-4 group-hover:scale-110 transition-transform duration-300" />
                <h3 className="font-semibold mb-2">Email</h3>
                <p className="text-sm text-gray-400 break-all">chandanasai1672004@gmail.com</p>
              </a>
              <a href="tel:+918919026938" className="bg-gray-900/50 p-6 rounded-lg border border-gray-700 hover:border-blue-400 transition-all duration-300 group">
                <Phone size={32} className="text-cyan-400 mx-auto mb-4 group-hover:scale-110 transition-transform duration-300" />
                <h3 className="font-semibold mb-2">Phone</h3>
                <p className="text-sm text-gray-400">+91-8919026938</p>
              </a>
              <a href="https://www.linkedin.com/in/chandana-sai-tatolu" target="_blank" rel="noopener noreferrer" className="bg-gray-900/50 p-6 rounded-lg border border-gray-700 hover:border-blue-400 transition-all duration-300 group">
                <Linkedin size={32} className="text-teal-400 mx-auto mb-4 group-hover:scale-110 transition-transform duration-300" />
                <h3 className="font-semibold mb-2">LinkedIn</h3>
                <p className="text-sm text-gray-400">Connect with me</p>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 py-8 border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-400 text-center md:text-left">
              2024 Chandana Sai Tatolu. All rights reserved.
            </p>
            <div className="flex gap-6">
              <a href="https://github.com/chandanasai1672004" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-blue-400 transition-colors duration-300">
                <Github size={24} />
              </a>
              <a href="https://www.linkedin.com/in/chandana-sai-tatolu" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-blue-400 transition-colors duration-300">
                <Linkedin size={24} />
              </a>
              <a href="mailto:chandanasai1672004@gmail.com" className="text-gray-400 hover:text-blue-400 transition-colors duration-300">
                <Mail size={24} />
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

function SkillCard({ title, skills, icon }: { title: string; skills: string[]; icon: React.ReactNode }) {
  return (
    <div className="bg-gray-900/50 p-6 rounded-lg border border-gray-700 hover:border-blue-400 transition-all duration-300 group">
      <div className="flex items-center gap-3 mb-4">
        <div className="group-hover:scale-110 transition-transform duration-300">{icon}</div>
        <h3 className="text-xl font-semibold">{title}</h3>
      </div>
      <div className="flex flex-wrap gap-2">
        {skills.map((skill, index) => (
          <span key={index} className="px-3 py-1 bg-gray-800 rounded-full text-sm text-gray-300 border border-gray-700">
            {skill}
          </span>
        ))}
      </div>
    </div>
  );
}

function EducationCard({ degree, major, institution, location, period, grade }: {
  degree: string;
  major: string;
  institution: string;
  location: string;
  period: string;
  grade: string;
}) {
  return (
    <div className="bg-gray-900/50 p-8 rounded-lg border border-gray-700 hover:border-blue-400 transition-all duration-300">
      <div className="flex items-start gap-4">
        <div className="p-3 bg-blue-500/10 rounded-lg">
          <GraduationCap size={24} className="text-blue-400" />
        </div>
        <div className="flex-1">
          <h3 className="text-2xl font-bold mb-1">{degree}</h3>
          {major && <p className="text-lg text-blue-400 mb-2">{major}</p>}
          <p className="text-gray-300 font-semibold">{institution}</p>
          <p className="text-gray-400 text-sm">{location}</p>
          <div className="flex flex-wrap gap-4 mt-3">
            <span className="text-gray-400">{period}</span>
            <span className="text-blue-400 font-semibold">{grade}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function ProjectCard({ title, description, tech, githubLink }: {
  title: string;
  description: string;
  tech: string[];
  githubLink: string;
}) {
  return (
    <div className="bg-gray-900/50 p-6 rounded-lg border border-gray-700 hover:border-blue-400 transition-all duration-300 group h-full flex flex-col">
      <h3 className="text-2xl font-bold mb-4 group-hover:text-blue-400 transition-colors duration-300">{title}</h3>
      <p className="text-gray-300 mb-4 flex-grow leading-relaxed">{description}</p>
      <div className="flex flex-wrap gap-2 mb-4">
        {tech.map((item, index) => (
          <span key={index} className="px-3 py-1 bg-gray-800 rounded-full text-xs text-gray-300 border border-gray-700">
            {item}
          </span>
        ))}
      </div>
      <a
        href={githubLink}
        target="_blank"
        rel="noopener noreferrer"
        className="inline-flex items-center gap-2 text-blue-400 hover:text-blue-300 transition-colors duration-300"
      >
        <Github size={20} />
        <span>View on GitHub</span>
      </a>
    </div>
  );
}

function CertificationCard({ title, issuer }: { title: string; issuer: string }) {
  return (
    <div className="bg-gray-900/50 p-6 rounded-lg border border-gray-700 hover:border-blue-400 transition-all duration-300">
      <Award size={32} className="text-blue-400 mb-4" />
      <h3 className="text-lg font-semibold mb-2">{title}</h3>
      <p className="text-gray-400 text-sm">{issuer}</p>
    </div>
  );
}

export default App;
